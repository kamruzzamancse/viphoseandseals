/**
 * Seals Filter JavaScript - Auto Filter on Keypress & Onchange
 */

jQuery(document).ready(function($) {
    
    var debounceTimer;
    function debounce(callback, delay) {
        clearTimeout(debounceTimer);
        debounceTimer = setTimeout(callback, delay);
    }
    
    function applyFilters() {
        var filterData = {
            'action': 'filter_seals_products',
            'product_type': $('#filter-type').val(),
            'id': $('#filter-id').val(),
            'id_tolerance': $('#id-tolerance').val(),
            'od': $('#filter-od').val(),
            'od_tolerance': $('#od-tolerance').val(),
            'height': $('#filter-height').val(),
            'height_tolerance': $('#height-tolerance').val(),
            'paged': 1
        };
        
        $.ajax({
            url: seals_ajax.ajax_url,
            type: 'POST',
            data: filterData,
            beforeSend: function() {
                $('.seals-products-wrapper').html('<div class="filter-loader" style="text-align:center;padding:50px;">Loading products...</div>');
            },
            success: function(response) {
                $('.seals-products-wrapper').html(response);
            },
            error: function(xhr, status, error) {
                console.log('AJAX Error:', error);
                $('.seals-products-wrapper').html('<div class="woocommerce-info">Error loading products. Please try again.</div>');
            }
        });
    }
    
    // Trigger filter on input keyup (with debounce)
    $('.seals-input').on('keyup', function(e) {
        debounce(function() {
            applyFilters();
        }, 500);
    });
    
    // Trigger filter on dropdown change
    $('.seals-select, .seals-tol-select').on('change', function() {
        applyFilters();
    });
});